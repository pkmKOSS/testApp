//
//  AddTaskRouter.swift
//  testProjectForSimbir
//
//  Created by Александр Григоренко on 10.02.2022.
//

import Foundation
import UIKit

class AddTaskRouter {
    // MARK: - External vars
    
    var viewController: UIViewController?
}

extension AddTaskRouter: AddTaskRoutingLogic {
    func routTo() {

    }
}
