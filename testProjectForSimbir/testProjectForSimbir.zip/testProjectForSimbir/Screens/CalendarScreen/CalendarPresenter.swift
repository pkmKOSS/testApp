//
//  CalendarPresenter.swift
//  testProjectForSimbir
//
//  Created by Александр Григоренко on 07.02.2022.
//

import Foundation

class CalendarPresenter {
    // MARK: - External vars
    var viewController: CalendarDisplayLigic?
    var dictionary = [String: TaskRealmModel]()
}

extension CalendarPresenter: CalendarPresentingLogic {
    func presentData(array: [TaskRealmModel]) {
        
        let dateFormatterForCell = DateFormatter() // 1. Создаём форматер
        dateFormatterForCell.locale = NSLocale.current // 2. задаём локацию
        dateFormatterForCell.dateFormat = "HH" // 3. Задаём формат даты - времени который нужен

        let dateFormatterForDictionary = DateFormatter()
        dateFormatterForDictionary.locale = NSLocale.current
        dateFormatterForDictionary.dateFormat = "yyyy:MM:dd"
        
        for (index, item) in array.enumerated() {
            let key = dateFormatterForDictionary.string(from: Date(timeIntervalSince1970: Double(item.task_date)!))

            let task = TaskRealmModel()
            
            task.task_time = dateFormatterForCell.string(from: Date(timeIntervalSince1970: Double(item.task_time)!))
            task.task_date = dateFormatterForDictionary.string(from: Date(timeIntervalSince1970: Double(item.task_date)!))
            task.id = item.id
            task.descriptionString = item.descriptionString
            task.name = item.name
            
            dictionary[key] = task
            
            if index == array.count - 1 {
            }
        }
        viewController?.displayData(array: dictionary) // 5. передаём во вью контроллер массив моделей с данными готовыми для отражения
    }
}




